module.exports = {
    plugins: {
        autoprefixer: {},
    },
};